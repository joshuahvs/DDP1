#Meminta input nama, asal daerah, hobi, jurusan, dan angkatan
nama_lengkap = input("Nama lengkap: ")
nama_panggilan = input("Nama panggilan: ")
asal_daerah = input("Asal: ")
hobi = input("Hobi: ")
jurusan = input("Jurusan: ")
angkatan = input("Angkatan: ")


#Mencetak perkenalan sesuai dengan data yang di input. 
print("Halo, namaku " + nama_lengkap + ", biasa dipanggil " + nama_panggilan + ". Aku dari jurusan " + jurusan + " " + angkatan + ". Aku asalnya dari " + asal_daerah \
      + ". Hobiku adalah " + hobi + ".")


